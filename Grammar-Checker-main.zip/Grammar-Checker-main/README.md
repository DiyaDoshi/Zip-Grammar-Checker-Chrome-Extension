# Gmail-Checker

This Grammar Checker is a Chrome extension designed to enhance your writing by providing real-time grammar corrections and explanations.
